> Referência da feature-test-design 1.16.0. Lida em: passos 5 e 7 e na escrita do `04` (antes de
> nomear fake, assertion ou helper num cenário). Fonte única de: as armadilhas de API que invalidam
> CT.

# Armadilhas de API que invalidam CT

Cada linha já produziu teste vermelho sem defeito no código — ou verde sem provar nada.

| Armadilha | Consequência |
|---|---|
| `Mail::assertSent` em mailable `ShouldQueue` | nunca passa — é `assertQueued` |
| `Event::fake()` **antes** das factories | eventos de model (uuid em `creating`) não rodam; fixture nasce quebrada |
| `Http::fake()` sem stub restrito | devolve 200 vazio para qualquer URL; `preventStrayRequests()` não bloqueia esse catch-all. Use `Http::fake(['{URL esperada}' => Http::response(...)])` + `Http::preventStrayRequests()` e afirme o payload enviado |
| `withoutExceptionHandling()` + `assertForbidden()` | o 403 vira exceção lançada; a assertion nunca roda |
| assumir que `RefreshDatabase` impede todo `->afterCommit()` | no Laravel 12.0.0, o manager de testes ignora a transação invólucro e executa callbacks; confira o manager da versão instalada e observe o despacho antes de declarar a lacuna |
| assumir que `travel()` sempre vaza para o teste seguinte | o `tearDown` padrão do Laravel 12.0.0 limpa Carbon e CarbonImmutable. Use closure/`travelBack()` para restaurar o relógio dentro do mesmo teste; em outro arnês, confira o cleanup |
| `Repeater::fake()` / `Builder::fake()` ausentes no Filament | UUID aleatório quebra `assertSchemaStateSet` |
| helper de teste declarado fora do `tests/Pest.php` e usado por 2 arquivos | `Call to undefined function` em `--parallel`, `--tia` ou arquivo isolado |
| `assertDatabaseHas` só com a chave primária | passa com todos os outros campos errados |
| `Log::spy()` citado como API oficial | é o mecanismo genérico de Facade Spy — funciona, mas não é doc |

Fontes primárias, fixadas no Laravel **12.0.0**: [`Factory::fake()`](https://github.com/laravel/framework/blob/v12.0.0/src/Illuminate/Http/Client/Factory.php),
[`DatabaseTransactionsManager`](https://github.com/laravel/framework/blob/v12.0.0/src/Illuminate/Foundation/Testing/DatabaseTransactionsManager.php)
e [`InteractsWithTestCaseLifecycle::tearDownTheTestEnvironment()`](https://github.com/laravel/framework/blob/v12.0.0/src/Illuminate/Foundation/Testing/Concerns/InteractsWithTestCaseLifecycle.php).
Para outra versão, confirmar no vendor do projeto.
